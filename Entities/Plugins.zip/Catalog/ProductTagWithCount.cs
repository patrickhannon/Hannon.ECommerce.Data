﻿namespace ECommerce.Data.Entities.Catalog
{
    public partial class ProductTagWithCount
    {
        public int ProductTagId { get; set; }

        public int ProductCount { get; set; }
    }
}
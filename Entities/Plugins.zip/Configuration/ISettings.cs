﻿namespace ECommerce.Data.Entities.Configuration
{
    /// <summary>
    /// Setting interface
    /// </summary>
    public interface ISettings
    {
    }
}
